import React, {Component, Fragment} from 'react';


class BlogLayout extends Component {


    constructor(props) {
        super(props);
    }

    render() {

        return(
            <Fragment>

            </Fragment>
        )

    }
}



export default BlogLayout;